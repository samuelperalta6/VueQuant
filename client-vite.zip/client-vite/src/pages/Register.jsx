import React from 'react';

const Register = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-lg rounded-xl px-8 py-10 w-full max-w-md text-black">
        <h2 className="text-2xl font-semibold text-center">Register Page</h2>
        {/* Add your register form elements or content here */}
      </div>
    </div>
  );
};

export default Register;
